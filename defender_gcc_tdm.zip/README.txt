Garrett Carter
Tyler McCormick

Inside of the base folder includes proj0 (base game)

Inside of the bonuses folder includes B1: Terrain and B9: New game theme and visuals. Both bonuses are included in proj1.

For B1 we implemented a star themed background.

For B2 we implemented aliens and other enemy types, created a ship, and changed the background.

